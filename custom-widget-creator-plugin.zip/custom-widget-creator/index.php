<?php
// Silence is golden!